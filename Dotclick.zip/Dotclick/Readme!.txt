1) Text 
2) Number of repetitions (1 time -> - <-)
3) Number of characters
4) Symbol (dot is recommended)